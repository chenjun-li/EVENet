import nibabel as nib
import numpy as np
import torch

import data_utils as du

# 加载三个 tensor
tensor1 = torch.load('/EVENetCNN/EVENetCNN/pred_prob_e3.pt')
tensor2 = torch.load('/EVENetCNN/EVENetCNN/pred_prob_md.pt')
tensor3 = torch.load('/EVENetCNN/EVENetCNN/pred_prob_fa.pt')

# 计算平均概率
average_tensor = (tensor1 + tensor2 + tensor3) / 3

average_tensor = average_tensor.float()
# 计算交叉熵作为不确定性
probs = torch.softmax(average_tensor, dim=-1)
log_probs = torch.log(probs)
uncertainty = -1.0 * (probs * log_probs).sum(dim=-1)

# 将不确定性保存为 heatmap
uncertainty_nii = nib.Nifti1Image(uncertainty.numpy(), np.eye(4))
nib.save(uncertainty_nii, 'deep_ensemble_heatmap.nii.gz')

# 计算每个 voxel 的最大概率种类
_, max_prob_class = torch.max(average_tensor, dim=-1)

# 保存分类结果
# max_prob_class_nii = nib.Nifti1Image(max_prob_class.numpy(), np.eye(4))
# nib.save(max_prob_class_nii, 'deep_ensemble_pred.nii.gz')

# map to freesurfer label space
muLut = du.read_classes_from_lut("/EVENetCNN/EVENetCNN/config/EVENet_ColorLUT3.tsv")
myLabels = muLut["ID"].values

pred_classes = du.map_label2aparc_aseg(max_prob_class, myLabels)
pred_classes = du.split_cortex_labels(pred_classes.cpu().numpy())

np_data = pred_classes if isinstance(pred_classes, np.ndarray) else pred_classes.cpu().numpy()

orig = nib.load("/data/dataset/patient/wm220/fa.nii.gz")
header = orig.header
save_as = "ensemble_pred"

du.save_image(header, orig.affine, np_data, save_as, dtype=np.int16)
